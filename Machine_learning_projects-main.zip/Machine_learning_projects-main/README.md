# Machine_learning_projects

This folder contains the jupyter notebook of mini machine learning projects
- guardian -- Predict university ranking based on the gaurdian survey data.
- Hr_analytics
- Iris_dataset
- titanic 
